package com.nisg.student.survey;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentSurveyApplicationTests {

	@Test
	void contextLoads() {
	}

}

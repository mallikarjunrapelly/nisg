create table stu_survy (
	studentid varchar(10),
	ans1_marks integer,
	ans2_marks integer,
	ans3_marks integer,
	ans4_marks integer,
	ans5_marks integer,
	ans6_marks integer,
	ans7_marks integer,
	ans8_marks integer,
	ans9_marks integer,
	ans10_marks integer,
	tot_marks integer,
	ans11 varchar(255),
	ans12 varchar(255)
);

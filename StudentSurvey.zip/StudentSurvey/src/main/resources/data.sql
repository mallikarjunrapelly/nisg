insert into stu_survy values('student1',4,3,4,4,2,3,1,0,2,0,23,'NONE','NA');
insert into stu_survy values('student2',2,4,4,4,2,4,1,0,2,1,24,'NONE','NA');
insert into stu_survy values('student3',3,0,4,4,2,3,1,3,2,0,22,'NONE','NA');

package com.nisg.student.survey.serviceImpl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nisg.student.survey.dao.StudentSurveyDao;
import com.nisg.student.survey.modal.StudentSurveyBean;
import com.nisg.student.survey.service.StudentService;

@Service
public class StudentSurveyServiceImpl implements StudentService {

	@Autowired
	StudentSurveyDao dao;
	
	@Override
	public ArrayList<StudentSurveyBean> showSurvey() {
		Map<String,Object> paramMap = new HashMap<String,Object>();
		ArrayList<StudentSurveyBean> sList = new ArrayList<StudentSurveyBean>();
		ArrayList<Map<String,Object>> rows = dao.showSurvey(paramMap);
		for(Map<String,Object> row : rows) {
			StudentSurveyBean sBean = new StudentSurveyBean();
			sBean.setStdId((String) row.get("studentid"));
			sBean.setM1((int) row.get("ans1_marks"));
			sBean.setM2((int) row.get("ans2_marks"));
			sBean.setM3((int) row.get("ans3_marks"));
			sBean.setM4((int) row.get("ans4_marks"));
			sBean.setM5((int) row.get("ans5_marks"));
			sBean.setM6((int) row.get("ans6_marks"));
			sBean.setM7((int) row.get("ans7_marks"));
			sBean.setM8((int) row.get("ans8_marks"));
			sBean.setM9((int) row.get("ans9_marks"));
			sBean.setM10((int) row.get("ans10_marks"));
			sBean.setTot((int) row.get("tot_marks"));
			sBean.setAns11((String) row.get("ans11"));
			sBean.setAns12((String) row.get("ans12"));
			sList.add(sBean);
		}
		return sList;
	}
	
	@Override
	public String saveSurvey(StudentSurveyBean sBean) {
		Map<String,Object> paramMap = new HashMap<String,Object>();
		paramMap.put("id", sBean.getStdId());
		paramMap.put("m1", sBean.getM1());
		paramMap.put("m2", sBean.getM2());
		paramMap.put("m3", sBean.getM3());
		paramMap.put("m4", sBean.getM4());
		paramMap.put("m5", sBean.getM5());
		paramMap.put("m6", sBean.getM6());
		paramMap.put("m7", sBean.getM7());
		paramMap.put("m8", sBean.getM8());
		paramMap.put("m9", sBean.getM9());
		paramMap.put("m10", sBean.getM10());
		paramMap.put("tot", sBean.getM1()+sBean.getM2()+sBean.getM3()+sBean.getM4()
						+sBean.getM5()+sBean.getM6()+sBean.getM7()+sBean.getM8()
						+sBean.getM9()+sBean.getM10());
		paramMap.put("ans11", sBean.getAns11());
		paramMap.put("ans12", sBean.getAns12());
		int count =  dao.saveSurvey(paramMap);
		if(count > 0) {
			return "Survey Saved Succesfully";
		}else {
			return "Error while saving survey details.Please try after some time";
		}
		
	}

}

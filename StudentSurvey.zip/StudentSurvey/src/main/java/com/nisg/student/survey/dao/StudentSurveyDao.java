package com.nisg.student.survey.dao;

import java.util.ArrayList;
import java.util.Map;


public interface StudentSurveyDao {
	
	public ArrayList<Map<String,Object>> showSurvey(Map<String,Object> paramMap);

	public int saveSurvey(Map<String, Object> paramMap);

}

package com.nisg.student.survey.service;

import java.util.ArrayList;

import com.nisg.student.survey.modal.StudentSurveyBean;

public interface StudentService {
	
	public ArrayList<StudentSurveyBean> showSurvey();

	public String saveSurvey(StudentSurveyBean sBean);
}

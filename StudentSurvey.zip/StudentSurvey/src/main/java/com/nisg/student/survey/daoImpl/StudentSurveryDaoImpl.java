package com.nisg.student.survey.daoImpl;

import java.util.ArrayList;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.nisg.student.survey.dao.StudentSurveyDao;

@Repository
public class StudentSurveryDaoImpl implements StudentSurveyDao {

	@Autowired
	NamedParameterJdbcTemplate npjt;
	
	@Override
	public ArrayList<Map<String,Object>> showSurvey(Map<String, Object> paramMap) {
		return (ArrayList<Map<String,Object>>) npjt.queryForList("select * from stu_survy", paramMap);
	}
	
	@Override
	public int saveSurvey(Map<String,Object> paramMap) {
		return npjt.update("insert into stu_survy values(:id,:m1,:m2,:m3,"
				+ ":m4,:m5,:m6,:m7,:m8,:m9,:m10,:tot,:ans11,:ans12)", paramMap);
	}

}

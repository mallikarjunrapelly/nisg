package com.nisg.student.survey.modal;

public class StudentSurveyBean {
	
	private String stdId;
	private int m1;
	private int m2;
	private int m3;
	private int m4;
	private int m5;
	private int m6;
	private int m7;
	private int m8;
	private int m9;
	private int m10;
	private int tot;
	private String ans11;
	private String ans12;
	public String getStdId() {
		return stdId;
	}
	public void setStdId(String stdId) {
		this.stdId = stdId;
	}
	public int getM1() {
		return m1;
	}
	public void setM1(int m1) {
		this.m1 = m1;
	}
	public int getM2() {
		return m2;
	}
	public void setM2(int m2) {
		this.m2 = m2;
	}
	public int getM3() {
		return m3;
	}
	public void setM3(int m3) {
		this.m3 = m3;
	}
	public int getM4() {
		return m4;
	}
	public void setM4(int m4) {
		this.m4 = m4;
	}
	public int getM5() {
		return m5;
	}
	public void setM5(int m5) {
		this.m5 = m5;
	}
	public int getM6() {
		return m6;
	}
	public void setM6(int m6) {
		this.m6 = m6;
	}
	public int getM7() {
		return m7;
	}
	public void setM7(int m7) {
		this.m7 = m7;
	}
	public int getM8() {
		return m8;
	}
	public void setM8(int m8) {
		this.m8 = m8;
	}
	public int getM9() {
		return m9;
	}
	public void setM9(int m9) {
		this.m9 = m9;
	}
	public int getM10() {
		return m10;
	}
	public void setM10(int m10) {
		this.m10 = m10;
	}
	public int getTot() {
		return tot;
	}
	public void setTot(int tot) {
		this.tot = tot;
	}
	public String getAns11() {
		return ans11;
	}
	public void setAns11(String ans11) {
		this.ans11 = ans11;
	}
	public String getAns12() {
		return ans12;
	}
	public void setAns12(String ans12) {
		this.ans12 = ans12;
	}
	
	

}

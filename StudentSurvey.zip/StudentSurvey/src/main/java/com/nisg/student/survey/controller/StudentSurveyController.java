package com.nisg.student.survey.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.nisg.student.survey.modal.StudentSurveyBean;
import com.nisg.student.survey.service.StudentService;

@RestController
public class StudentSurveyController {
	
	@Autowired
	StudentService srv;
	
	@GetMapping("/surveys")
	public ArrayList<StudentSurveyBean> showSurvey(){
		return srv.showSurvey();
	}
	
	@PostMapping("/surveys")
	public String saveSurvey(@RequestBody StudentSurveyBean sBean) {
		return srv.saveSurvey(sBean);
		
	}
	

}
